/**
 * 
 */
package soquery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Reference;
import javax.jcr.Session;
//Sling Imports
import org.apache.sling.api.resource.ResourceResolverFactory ; 
import org.apache.sling.api.resource.ResourceResolver; 
//QUeryBuilder APIs
import com.day.cq.search.QueryBuilder; 
import com.day.cq.search.Query; 
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.result.SearchResult;
import com.day.cq.search.result.Hit; 


//This is a component so it can provide or consume services
@Component

@Service
/**
 * @author sonu.bansal
 *
 */
public class SoqueryImpl implements TestqueryService {
	
	/** Default log. */
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private Session session;

	//Inject a Sling ResourceResolverFactory
	@Reference
	private ResourceResolverFactory resolverFactory;

	@Reference
	private QueryBuilder builder;

	@Override
	public String getSearchResult() {
		try { 

			//Invoke the adaptTo method to create a Session 
			ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			session = resourceResolver.adaptTo(Session.class);

			String fulltextSearchTerm = "Hello";

			// create query description as hash map (simplest way, same as form post)
			Map<String, String> map = new HashMap<String, String>();

			// create query description as hash map (simplest way, same as form post)

			/*map.put("path", "/content");
			map.put("type", "cq:Page");
			map.put("group.p.or", "true"); // combine this group with OR
			map.put("group.1_fulltext", fulltextSearchTerm);
			map.put("group.1_fulltext.relPath", "jcr:content");
			map.put("group.2_fulltext", fulltextSearchTerm);
			map.put("group.2_fulltext.relPath", "jcr:content/@cq:tags");
			// can be done in map or with Query methods
			map.put("p.offset", "0"); // same as query.setStart(0) below
			map.put("p.limit", "20"); // same as query.setHitsPerPage(20) below
			
*/			
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -6);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");  
		    String strDate= formatter.format(cal.getTime());  
			//System.out.println(""+strDate);
			
			map.put("path", "/content/training/");
			map.put("type", "cq:Page");
			map.put("1_property", "jcr:created");
			map.put("1_property.lowerBound", strDate);
			map.put("1_property.lowerOperation ", ">");
			
			Query query = builder.createQuery(PredicateGroup.create(map), session);

			query.setStart(0);
			query.setHitsPerPage(20);

			SearchResult result = query.getResult();




			// iterating over the results
			String path = "";
			for (Hit hit : result.getHits()) {
				 path = path + "\n"+ hit.getPath();		
			}

			//close the session
			session.logout();

			// return data 
			return path;

		}
		catch(Exception e){
			log.info(e.getMessage());
		}
		return null; 
	}
}
