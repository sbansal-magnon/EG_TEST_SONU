/**
 * 
 */
package soquery;

/**
 * @author sonu.bansal
 *
 */
public interface TestqueryService {
	 public String getSearchResult();
}
