/**
 * 
 */
package aem.so.assignmentprg1;

import java.util.ArrayList;

import soquerykeyword.FromDataMapper;

/**
 * @author sonu.bansal
 *
 */
public interface QueryListService {
	
	public String listPages();
	public ArrayList<FromDataMapper> getRecordListing();

}
