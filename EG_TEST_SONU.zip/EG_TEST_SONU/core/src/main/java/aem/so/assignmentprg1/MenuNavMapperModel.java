package aem.so.assignmentprg1;

public class MenuNavMapperModel {
	private String title;
	private String path;
	private String sorder;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getSorder() {
		return sorder;
	}
	public void setSorder(String sorder) {
		this.sorder = sorder;
	}
	
}
