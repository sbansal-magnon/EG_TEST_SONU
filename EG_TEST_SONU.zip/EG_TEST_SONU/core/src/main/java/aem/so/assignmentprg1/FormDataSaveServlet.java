package aem.so.assignmentprg1;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import java.io.IOException;
import java.rmi.ServerException;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.commons.json.JSONObject;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.jcr.Node;
import org.apache.jackrabbit.commons.JcrUtils;
import javax.jcr.Session;
//Sling Imports
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceResolver;

@SlingServlet(paths = "/bin/soAssignmentPrg1FormSaveServlet", methods = "GET", metatype = false)
public class FormDataSaveServlet extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
	private static final long serialVersionUID = 2598426539166789515L;

	/** Default log. */
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	// Inject a Sling ResourceResolverFactory
	@Reference
	private ResourceResolverFactory resolverFactory;

	private Session session;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServerException, IOException {

		try {
			// Get the submitted form data that is sent from the
			// CQ web page
			String id = UUID.randomUUID().toString();
			String emp_fname = request.getParameter("emp_fname");
			String emp_lname = request.getParameter("emp_lname");
			String emp_code = request.getParameter("emp_code");
			String emp_email = request.getParameter("emp_email");
			String emp_mobile = request.getParameter("emp_mobile");
			String emp_mobile_type = request.getParameter("emp_mobile_type");
			String emp_current_address = request.getParameter("emp_current_address");

			// Encode the submitted form data to JSON
			JSONObject obj = new JSONObject();
			obj.put("id", id);
			obj.put("emp_fname", emp_fname);
			obj.put("emp_lname", emp_lname);
			obj.put("emp_code", emp_code);
			obj.put("emp_email", emp_email);
			obj.put("emp_mobile", emp_mobile);
			obj.put("emp_mobile_type", emp_mobile_type);
			obj.put("emp_current_address", emp_current_address);

			// Get the JSON formatted data
			String jsonData = obj.toString();

			// Invoke the adaptTo method to create a Session
			ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			session = resourceResolver.adaptTo(Session.class);

			// Create a node that represents the root node
			Node root = session.getRootNode();

			// Get the content node in the JCR
			Node content = root.getNode("content/training/sonu");

			// Determine if the content/customer node exists
			Node customerRoot = null;
			int custRec = doesNodeExist(content);

			// -1 means that content/customer does not exist
			if (custRec == -1)
				// content/customer does not exist -- create it
				customerRoot = content.addNode("formdata", "sling:OrderedFolder");
			else
				// content/customer does exist -- retrieve it
				customerRoot = content.getNode("formdata");

			
			// Store content from the client JSP in the JCR
			Node custNode = customerRoot.addNode("formdata" + id, "nt:unstructured");

			// make sure name of node is unique
			custNode.setProperty("id", id);
			custNode.setProperty("emp_fname", emp_fname);
			custNode.setProperty("emp_lname", emp_lname);
			custNode.setProperty("emp_code", emp_code);
			custNode.setProperty("emp_email", emp_email);
			custNode.setProperty("emp_mobile", emp_mobile);
			custNode.setProperty("emp_mobile_type", emp_mobile_type);
			custNode.setProperty("emp_current_address", emp_current_address);

			// Save the session changes and log out
			session.save();
			session.logout();
			// Return the JSON formatted data
			response.getWriter().write(jsonData);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private int doesNodeExist(Node content) {
		try {
			java.lang.Iterable<Node> custNode = JcrUtils.getChildNodes(content, "formdata");
			//Iterator it = custNode.iterator();
			// only going to be 1 content/customer node if it exists
			if (custNode.iterator().hasNext()) {
				return 1;
			} else {
				return -1; // content/customer does not exist
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
}
