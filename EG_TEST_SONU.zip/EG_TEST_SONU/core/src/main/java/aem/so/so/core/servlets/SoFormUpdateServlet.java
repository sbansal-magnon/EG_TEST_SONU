package aem.so.so.core.servlets;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import java.io.IOException;
import java.rmi.ServerException;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.jcr.api.SlingRepository;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.Node;
import org.apache.jackrabbit.commons.JcrUtils;
import javax.jcr.Session;
//Sling Imports
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.resource.ResourceResolver;

@SlingServlet(paths = "/bin/soFormUpdateDataServlet", methods = "GET", metatype = false)
public class SoFormUpdateServlet extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
	private static final long serialVersionUID = 2598426539166789515L;

	@Reference
	private SlingRepository repository;

	/** Default log. */
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	// Inject a Sling ResourceResolverFactory
	@Reference
	private ResourceResolverFactory resolverFactory;

	private Session session;

	public void bindRepository(SlingRepository repository) {
		this.repository = repository;
	}
	
	@Reference
	private QueryBuilder builder;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServerException, IOException {

		try {
			// Get the submitted form data that is sent from the
			
			String id = request.getParameter("id");
			String emp_fname = request.getParameter("emp_fname");
			String emp_lname = request.getParameter("emp_lname");
			String emp_code = request.getParameter("emp_code");
			String emp_email = request.getParameter("emp_email");
			String emp_mobile = request.getParameter("emp_mobile");
			String emp_mobile_type = request.getParameter("emp_mobile_type");
			String emp_current_address = request.getParameter("emp_current_address");
			
			// Invoke the adaptTo method to create a Session
			ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			session = resourceResolver.adaptTo(Session.class);

			// Create a node that represents the root node
			Node root = session.getRootNode();

			// Get the content node in the JCR
			Node content = root.getNode("content/training/sonu/formdata/formdata"+id);
			
			// make sure name of node is unique
			content.setProperty("emp_fname", emp_fname);
			content.setProperty("emp_lname", emp_lname);
			content.setProperty("emp_code", emp_code);
			content.setProperty("emp_email", emp_email);
			content.setProperty("emp_mobile", emp_mobile);
			content.setProperty("emp_mobile_type", emp_mobile_type);
			content.setProperty("emp_current_address", emp_current_address);
			
			// Save the session changes and log out
			session.save();
			session.logout();
			// Return the JSON formatted data
			response.getWriter().write("updated");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}