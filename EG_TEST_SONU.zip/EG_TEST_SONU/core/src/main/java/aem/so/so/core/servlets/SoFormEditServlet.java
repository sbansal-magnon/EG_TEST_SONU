package aem.so.so.core.servlets;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;

import java.io.IOException;
import java.rmi.ServerException;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.jcr.api.SlingRepository;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

import java.util.HashMap;
import java.util.Map;
import javax.jcr.Session;

@SlingServlet(paths = "/bin/soFormEditServlet", methods = "GET", metatype = false)
public class SoFormEditServlet extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
	private static final long serialVersionUID = 2598426539166789515L;

	@Reference
	private SlingRepository repository;

	public void bindRepository(SlingRepository repository) {
		this.repository = repository;
	}

	private Session session;

	// Inject a Sling ResourceResolverFactory
	@Reference
	private ResourceResolverFactory resolverFactory;

	@Reference
	private QueryBuilder builder;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServerException, IOException {

		try {
			// Get the submitted form data that is sent from the
			// CQ web page
			String id = request.getParameter("id");
			// create query description as hash map (simplest way, same as form post)

			ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			session = resourceResolver.adaptTo(Session.class);

			Map<String, String> map = new HashMap<String, String>();

			// create query description as hash map (simplest way, same as form post)

			map.put("path", "/content/training/sonu/formdata/");
			map.put("type", "nt:unstructured");
			map.put("1_property", "id");
			map.put("1_property.value", id);
			Query query = builder.createQuery(PredicateGroup.create(map), session);

			SearchResult result = query.getResult();
			JSONObject obj = new JSONObject();
			for (Hit hit : result.getHits()) {
				ValueMap valueMap = hit.getProperties();
				obj.put("id", valueMap.get("id"));
				obj.put("emp_fname", valueMap.get("emp_fname"));
				obj.put("emp_lname", valueMap.get("emp_lname"));
				obj.put("emp_code", valueMap.get("emp_code"));
				obj.put("emp_email", valueMap.get("emp_email"));
				obj.put("emp_mobile", valueMap.get("emp_mobile"));
				obj.put("emp_mobile_type", valueMap.get("emp_mobile_type"));
				obj.put("emp_current_address", valueMap.get("emp_current_address"));
			}
			// Get the JSON formatted data
			String jsonData = obj.toString();
			// Return the JSON formatted data
			response.getWriter().write(jsonData);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
