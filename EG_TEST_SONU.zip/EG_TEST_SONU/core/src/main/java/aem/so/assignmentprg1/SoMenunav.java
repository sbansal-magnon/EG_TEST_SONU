package aem.so.assignmentprg1;

import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = Resource.class)
public class SoMenunav {
	
	ArrayList<MenuNavMapperModel> filedValues; 
	@Inject @Named("countries") @Default(values="No resourceType")
	@Optional
	private Resource iItems;

	private String message;
	@PostConstruct
	protected void init() {
		try {
			MenuNavMapperModel values1 = new MenuNavMapperModel();
			values1.setTitle("ss");
			values1.setPath("ddd");	
			filedValues.add(values1);
			
		filedValues = new ArrayList<MenuNavMapperModel>();
		if(iItems != null && iItems.hasChildren()){
			for (Resource resource : iItems.getChildren()){
				if(resource != null){
					MenuNavMapperModel values = new MenuNavMapperModel();
					values.setTitle(""+resource.getValueMap().get("title"));
					values.setPath(""+resource.getValueMap().get("path"));
					filedValues.add(values);
					message +=  "\n page name ::: "+resource.getValueMap().get("title");
				}
			}
		}
		}catch (Exception e) {
			message += e.getMessage(); //e.getMessage();// " e.printStackTrace();
		}	
		
	}
	public ArrayList<MenuNavMapperModel> getFiledValues() {
		return filedValues;
	}

	public Resource getiItems() {
		return iItems;
	}

	public String getMessage() {
		return message;
	}

}
