package aem.so.so.core.servlets;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class)
public class FirstSlingModel {
	@Inject
	private String designation;
	@Inject
	private String department;
	@Inject
	private String experience;

	public String getDesignation() {
		return designation;
	}

	public String getDepartment() {
		return department;
	}

	public String getExperience() {
		return experience;
	}

}
