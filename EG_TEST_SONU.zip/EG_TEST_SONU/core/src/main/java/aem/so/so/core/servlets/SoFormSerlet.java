package aem.so.so.core.servlets;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import java.io.IOException;
import java.rmi.ServerException;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.jcr.api.SlingRepository;
import java.util.UUID;
 
@SlingServlet(paths="/bin/soFormServlet", methods = "GET", metatype=false)
public class SoFormSerlet extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
     private static final long serialVersionUID = 2598426539166789515L;
      
     @Reference
     private SlingRepository repository;
      
     public void bindRepository(SlingRepository repository) {
            this.repository = repository; 
            }
           
     @Override
     protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
       
      try
      {
         //Get the submitted form data that is sent from the
              //CQ web page  
          String id = UUID.randomUUID().toString();
          String emp_fname = request.getParameter("emp_fname");
          String emp_lname = request.getParameter("emp_lname");
          String emp_code = request.getParameter("emp_code");
          String emp_email = request.getParameter("emp_email");
          String emp_mobile = request.getParameter("emp_mobile");
          String emp_mobile_type = request.getParameter("emp_mobile_type");
          String emp_current_address = request.getParameter("emp_current_address"); 
          
          //Encode the submitted form data to JSON
          JSONObject obj=new JSONObject();
          obj.put("id",id);
          obj.put("emp_fname",emp_fname);
          obj.put("emp_lname",emp_lname);
          obj.put("emp_code",emp_code);
          obj.put("emp_email",emp_email);
          obj.put("emp_mobile",emp_mobile);
          obj.put("emp_mobile_type",emp_mobile_type);
          obj.put("emp_current_address",emp_current_address);
         
           
             //Get the JSON formatted data    
          String jsonData = obj.toString();
           
             //Return the JSON formatted data
         response.getWriter().write(jsonData);
      }
      catch(Exception e)
      {
          e.printStackTrace();
      }
    }
}