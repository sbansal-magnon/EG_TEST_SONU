/**
 * 
 */
package aem.so.assignmentprg1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Reference;
import javax.jcr.Session;
//Sling Imports
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.resource.ResourceResolver;
//QUeryBuilder APIs
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.Query;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.result.SearchResult;

import soquerykeyword.FromDataMapper;

import com.day.cq.search.result.Hit;

@Component

@Service
/**
 * @author sonu.bansal
 *
 */
public class QueryListImpl implements QueryListService {
	/** Default log. */
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private Session session;

	// Inject a Sling ResourceResolverFactory
	@Reference
	private ResourceResolverFactory resolverFactory;

	@Reference
	private QueryBuilder builder;

	/*
	 * (non-Javadoc)
	 * 
	 * @see aem.so.assignmentprg1.QueryListService#listPages()
	 */
	@Override
	public String listPages() {
		// TODO Auto-generated method stub

		try {

			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -6);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String strDate = formatter.format(cal.getTime());
			// System.out.println(""+strDate);

			ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			session = resourceResolver.adaptTo(Session.class);

			Map<String, String> map = new HashMap<String, String>();

			// create query description as hash map (simplest way, same as form post)

			map.put("path", "/content/training/");
			map.put("type", "cq:Page");
			map.put("1_property", "jcr:created");
			map.put("1_property.lowerBound", strDate);
			map.put("1_property.lowerOperation ", ">");
			Query query = builder.createQuery(PredicateGroup.create(map), session);

			SearchResult result = query.getResult();
			String path = "";
			for (Hit hit : result.getHits()) {
				path = path + "\n" + hit.getPath();
			}
			// Return the JSON formatted data
			return path;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public ArrayList<FromDataMapper> getRecordListing() {
		try {

			// Invoke the adaptTo method to create a Session
			ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			session = resourceResolver.adaptTo(Session.class);
			
			// create query description as hash map (simplest way, same as form post)
			Map<String, String> map = new HashMap<String, String>();

			// create query description as hash map (simplest way, same as form post)

			map.put("path", "/content/training/sonu/formdata/");
			map.put("type", "nt:unstructured");
			map.put("orderby", "@id");
			Query query  = builder.createQuery(PredicateGroup.create(map), session);

			

			SearchResult result = query.getResult();

			// iterating over the results
			ArrayList<FromDataMapper> arryList = new ArrayList<FromDataMapper>();
			for (Hit hit : result.getHits()) {
				ValueMap valueMap = hit.getProperties();
				FromDataMapper fdata = new FromDataMapper();
				
				fdata.setEmp_fname(valueMap.get("emp_fname").toString());
				fdata.setEmp_lname(valueMap.get("emp_lname").toString());
				fdata.setEmp_code(valueMap.get("emp_code").toString());
				fdata.setEmp_email(valueMap.get("emp_email").toString());
				fdata.setEmp_mobile(valueMap.get("emp_mobile").toString());
				fdata.setEmp_mobile_type(valueMap.get("emp_mobile_type").toString());
				fdata.setEmp_current_address(valueMap.get("emp_current_address").toString());
				fdata.setId(valueMap.get("id").toString());
				arryList.add(fdata);
			}

			// close the session
			session.logout();

			// return data
			return arryList;

		} catch (Exception e) {
			log.info(e.getMessage());
		}
		return null;
	}

}
