package aem.so.assignmentprg1;

import org.apache.commons.mail.Email;
import org.apache.commons.mail.SimpleEmail;

import com.day.cq.mailer.MessageGateway;

public class Mailtestso {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			// Set up the Email message
			Email email = new SimpleEmail();

			// Set the mail values
			String emailToRecipients = "sonu.bansal@magnontbwa.com";
			//String emailCcRecipients = "wblue@nomailserver.com";
				
			// Set up the Email message
			email.setHostName("smtp.gmail.com");
			//email.setSmtpPort(25);
			email.setSSL(true);
			email.setAuthentication("testtrainingmagnon@gmail.com", "M@gn0ntbwa");
			
			email.addTo(emailToRecipients);
			//email.addCc(emailCcRecipients);
			email.setSubject("AEM Custom Step");
			email.setFrom("scottm@adobe.com");
			email.setMsg("This message is to inform you that the CQ content has been deleted");
			email.send();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
