package aem.so.assignmentprg1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.jcr.Session;
import javax.annotation.PostConstruct;

import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

import soquerykeyword.FromDataMapper;

@Model(adaptables = Resource.class)
public class SoMenuNavSling {
	ArrayList<MenuNavMapperModel> arryList = new ArrayList<MenuNavMapperModel>();
	private Session session;

	// Inject a Sling ResourceResolverFactory
	@Reference
	private ResourceResolverFactory resolverFactory;

	@Reference
	private QueryBuilder builder;
	
	
	String data = "sonu";
	@Inject
	@Named("countries")
	@Default(values = "No resourceType")
	@Optional
	private Resource rows;
	protected Logger log = LoggerFactory.getLogger(this.getClass());
	@PostConstruct
	protected void init() {
		log.info("wwww::");
		try {
			this.data += "sdsdsds";
		} catch (Exception e) {
			log.info("sass::"+e.getMessage());
		}

		
	}
	public String getData() {
		return data;
	}


	
}
