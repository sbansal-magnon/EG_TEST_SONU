/**
 * 
 */
package soformdata;

/**
 * @author sonu.bansal
 *
 */
public interface SaveformService {
	
	public int addFormData();

}
