/**
 * 
 */
package soformdata;

/**
 * @author sonu.bansal
 *
 */
public class SavefordataImpl implements SaveformService {

	/* (non-Javadoc)
	 * @see soformdata.SaveformService#addFormData()
	 */
	@Override
	public int addFormData() {
		// TODO Auto-generated method stub
		return 0;
	}

}
