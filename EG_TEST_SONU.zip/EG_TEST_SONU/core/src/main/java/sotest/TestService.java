package sotest;

public interface TestService {
	
	 public String showText(); 

}
