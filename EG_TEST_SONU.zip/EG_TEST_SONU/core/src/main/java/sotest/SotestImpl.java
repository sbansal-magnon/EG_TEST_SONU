package sotest;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;

@Component

@Service
public class SotestImpl implements TestService  {

	@Override
	public String showText() {
		// TODO Auto-generated method stub
		return "My First Service";
	}
}
