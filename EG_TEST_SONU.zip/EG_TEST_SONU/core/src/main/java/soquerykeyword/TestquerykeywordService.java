/**
 * 
 */
package soquerykeyword;

import java.util.ArrayList;

/**
 * @author sonu.bansal
 *
 */
public interface TestquerykeywordService {
	public String getSearchResultByKeyword();
	public ArrayList<FromDataMapper> getSearchResultByMapper();
}
