/**
 * 
 */
package soquerykeyword;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.Map;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Reference;
import javax.jcr.Session;
//Sling Imports
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.api.resource.ResourceResolver;
//QUeryBuilder APIs
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.Query;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.result.SearchResult;
import com.day.cq.search.result.Hit;

@Component

@Service
/**
 * @author sonu.bansal
 *
 */
public class SoquerykeywordImpl implements TestquerykeywordService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * soquerykeyword.TestquerykeywordService#getSearchResultByKeyword(java.lang.
	 * String)
	 */
	/** Default log. */
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private Session session;

	
	// Inject a Sling ResourceResolverFactory
	@Reference
	private ResourceResolverFactory resolverFactory;

	@Reference
	private QueryBuilder builder;

	private String keyword;

	public SoquerykeywordImpl() {

	}

	public SoquerykeywordImpl(String text) {
		keyword = text;
	}

	@Override
	public String getSearchResultByKeyword() {
		try {

			// Invoke the adaptTo method to create a Session
			ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			session = resourceResolver.adaptTo(Session.class);
			String key = "";
			if (keyword == null) {
				key = "test";
			} else {
				key = keyword;
			}
			String fulltextSearchTerm = key;

			// create query description as hash map (simplest way, same as form post)
			Map<String, String> map = new HashMap<String, String>();

			// create query description as hash map (simplest way, same as form post)

			map.put("path", "/content/training/sonu/formdata/");
			map.put("type", "nt:unstructured");
			map.put("orderby", "@id");
			Query query  = builder.createQuery(PredicateGroup.create(map), session);

			

			SearchResult result = query.getResult();

			// iterating over the results
			String path = "";
			ArrayList<String> arryList = new ArrayList<String>();
			for (Hit hit : result.getHits()) {
				ValueMap valueMap = hit.getProperties();
				
				JSONObject obj = new JSONObject();
				obj.put("id", valueMap.get("id"));
				obj.put("emp_fname", valueMap.get("emp_fname"));
				obj.put("emp_lname", valueMap.get("emp_lname"));
				obj.put("emp_code", valueMap.get("emp_code"));
				obj.put("emp_email", valueMap.get("emp_email"));
				obj.put("emp_mobile", valueMap.get("emp_mobile"));
				obj.put("emp_mobile_type", valueMap.get("emp_mobile_type"));
				obj.put("emp_current_address", valueMap.get("emp_current_address"));
				arryList.add(obj.toString());
				obj=null ;
				// path = path + "\n"+ hit..getProperties();
			}

			// close the session
			session.logout();

			// return data
			return arryList.toString();

		} catch (Exception e) {
			log.info(e.getMessage());
		}
		return null;
	}
	
	
	@Override
	public ArrayList<FromDataMapper> getSearchResultByMapper() {
		try {

			// Invoke the adaptTo method to create a Session
			ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			session = resourceResolver.adaptTo(Session.class);
			
			// create query description as hash map (simplest way, same as form post)
			Map<String, String> map = new HashMap<String, String>();

			// create query description as hash map (simplest way, same as form post)

			map.put("path", "/content/training/sonu/formdata/");
			map.put("type", "nt:unstructured");
			map.put("orderby", "@id");
			Query query  = builder.createQuery(PredicateGroup.create(map), session);

			

			SearchResult result = query.getResult();

			// iterating over the results
			ArrayList<FromDataMapper> arryList = new ArrayList<FromDataMapper>();
			for (Hit hit : result.getHits()) {
				ValueMap valueMap = hit.getProperties();
				FromDataMapper fdata = new FromDataMapper();
				
				fdata.setEmp_fname(valueMap.get("emp_fname").toString());
				fdata.setEmp_lname(valueMap.get("emp_lname").toString());
				fdata.setEmp_code(valueMap.get("emp_code").toString());
				fdata.setEmp_email(valueMap.get("emp_email").toString());
				fdata.setEmp_mobile(valueMap.get("emp_mobile").toString());
				fdata.setEmp_mobile_type(valueMap.get("emp_mobile_type").toString());
				fdata.setEmp_current_address(valueMap.get("emp_current_address").toString());
				fdata.setId(valueMap.get("id").toString());
				arryList.add(fdata);
			}

			// close the session
			session.logout();

			// return data
			return arryList;

		} catch (Exception e) {
			log.info(e.getMessage());
		}
		return null;
	}

}
