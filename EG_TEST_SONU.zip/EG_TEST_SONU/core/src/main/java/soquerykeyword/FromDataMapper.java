/**
 * 
 */
package soquerykeyword;

/**
 * @author sonu.bansal
 *
 */
public class FromDataMapper {
	
	private String emp_fname;
	private String emp_lname;
	private String emp_code;
	private String emp_email;
	private String emp_mobile;
	private String emp_mobile_type;
	private String emp_current_address;
	private String id;
	
	public String getEmp_fname() {
		return emp_fname;
	}


	public void setEmp_fname(String emp_fname) {
		this.emp_fname = emp_fname;
	}


	public String getEmp_lname() {
		return emp_lname;
	}


	public void setEmp_lname(String emp_lname) {
		this.emp_lname = emp_lname;
	}


	public String getEmp_code() {
		return emp_code;
	}


	public void setEmp_code(String emp_code) {
		this.emp_code = emp_code;
	}


	public String getEmp_email() {
		return emp_email;
	}


	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}


	public String getEmp_mobile() {
		return emp_mobile;
	}


	public void setEmp_mobile(String emp_mobile) {
		this.emp_mobile = emp_mobile;
	}


	public String getEmp_mobile_type() {
		return emp_mobile_type;
	}


	public void setEmp_mobile_type(String emp_mobile_type) {
		this.emp_mobile_type = emp_mobile_type;
	}


	public String getEmp_current_address() {
		return emp_current_address;
	}


	public void setEmp_current_address(String emp_current_address) {
		this.emp_current_address = emp_current_address;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}
}
